#!/bin/sh
tar -czf ece454750a2.tar.gz build.xml samplegraph.txt maketarball.sh src/
